<template>
  <el-menu-item :index="routerInfo.name">
    <i :class="'el-icon-'+routerInfo.meta.icon"></i>
    <span slot="title">{{routerInfo.meta.title}}</span>
  </el-menu-item>
</template>

<script>
export default {
  name: 'MenuItem',
  props: {
    routerInfo: {
      default: () => {
        return null
      },
      type: Object
    }
  }
}
</script>

<style lang="scss">
</style>
