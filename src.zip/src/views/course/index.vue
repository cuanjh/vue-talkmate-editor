<template>
  <router-view></router-view>
</template>

<script>
export default {
  name: 'CourseManage'
}
</script>

<style lang="scss">
</style>
