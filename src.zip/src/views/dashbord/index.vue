<template>
  <div>仪表盘</div>
</template>
