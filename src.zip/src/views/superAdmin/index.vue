<template>
    <router-view></router-view>
</template>

<script>
export default {
  name: 'SuperAdmin'
}
</script>

<style lang="scss">
</style>
